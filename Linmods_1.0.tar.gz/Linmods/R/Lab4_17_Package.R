#' Linear regression models
#'
#' This package is used to fitting linear regression models. Using the "linreg" function you can fit a model and get several components which belongs to the model.

#' @docType package
#'
#' @author Ahmet Akdeve \email{ahmak554@student.liu.se}
#' @author Zhixuan Duan \email{darinstu999@gmail.com}
#'
#' @name Linmods
#' 
NULL